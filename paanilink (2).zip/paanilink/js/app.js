import { api } from './api.js';

const me = JSON.parse(sessionStorage.getItem('user'));
if (!me) location.replace('login.html');

const $ = s => document.querySelector(s);
const LIMIT = 2; // subsidised bookings per customer per month
const ACTIVE = ['Assigned', 'Filled', 'Dispatched', 'Arrived'];
const NAV = {
  customer: ['bookings', 'book', 'subsidy'],
  officer: ['approvals', 'applications', 'disputes', 'zone'],
  operator: ['dispatch', 'fleet'],
  driver: ['trips'],
  admin: ['overview', 'zones', 'hydrants', 'tankers', 'rates', 'users']
};
const HERO = { customer: 'Book water, track your tanker', officer: 'Zone approvals and disputes', operator: 'Hydrant dispatch', driver: 'My trips', admin: 'City operations' };

const money = n => 'Rs ' + n.toLocaleString();
const badge = s => `<span class="badge ${String(s).toLowerCase()}">${s}</span>`;
const btn = (act, id, label, cls = '') => `<button class="btn ${cls}" data-act="${act}" data-id="${id}">${label}</button>`;
const table = (heads, rows) => rows.length
  ? `<div class="table-wrap"><table><thead><tr>${heads.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`
  : '<p class="empty">Nothing here yet.</p>';
const panel = (title, body) => `<section class="panel"><h2>${title}</h2>${body}</section>`;
const options = (items, label) => items.map(i => `<option value="${i.id}">${label(i)}</option>`).join('');
const find = async (name, id) => (await api.list(name)).find(i => i.id === id);
const stamp = status => ({ status, at: new Date().toLocaleString(), by: me.name });

async function setStatus(b, status, extra = {}) {
  await api.update('bookings', b.id, { ...extra, status, history: [...b.history, stamp(status)] });
}
async function releaseWater(b) {
  const h = await find('hydrants', b.hydrant);
  await api.update('hydrants', h.id, { used: Math.max(0, h.used - b.size) });
}

/* Actions each role may take on a booking, by status */
function actions(b) {
  const a = [btn('trail', b.id, 'Trail')];
  if (me.role === 'customer') {
    if (['Pending', 'Approved'].includes(b.status)) a.push(btn('cancel', b.id, 'Cancel', 'danger'));
    if (b.status === 'Delivered') a.push(btn('confirm', b.id, 'Confirm', 'primary'), btn('dispute', b.id, 'Dispute', 'danger'));
  }
  if (me.role === 'officer') {
    if (b.status === 'Pending') a.push(btn('approve', b.id, 'Approve', 'primary'), btn('reject', b.id, 'Reject', 'danger'));
    if (b.status === 'Disputed') a.push(btn('resolve', b.id, 'Resolve', 'primary'));
  }
  return a.join('');
}
async function bookingTable(filter, withCustomer = false) {
  const [bookings, tankers] = await Promise.all([api.list('bookings'), api.list('tankers')]);
  const heads = ['ID', ...(withCustomer ? ['Customer'] : []), 'Size', 'Type', 'Status', 'Tanker', 'Bill', 'Actions'];
  return table(heads, bookings.filter(filter).map(b => [
    b.id, ...(withCustomer ? [b.customerName] : []), b.size.toLocaleString() + ' gal', b.type, badge(b.status),
    tankers.find(t => t.id === b.tanker)?.plate ?? '-', money(b.amount), actions(b)]));
}

const views = {
  async bookings() { return panel('My bookings', await bookingTable(b => b.customer === me.id)); },

  async book() {
    const [hydrants, rates] = await Promise.all([api.list('hydrants'), api.rates()]);
    return panel('Book a tanker', `<form data-form="book" novalidate>
      <div class="form-grid">
        <div><label for="size">Tanker size</label><select id="size" name="size" required>${Object.keys(rates.commercial).map(s => `<option value="${s}">${(+s).toLocaleString()} gallons</option>`).join('')}</select></div>
        <div><label for="type">Booking type</label><select id="type" name="type" required><option value="commercial">Commercial</option>${me.subsidy === 'Verified' ? '<option value="subsidised">Subsidised</option>' : ''}</select></div>
        <div><label for="hydrant">Hydrant</label><select id="hydrant" name="hydrant" required>${options(hydrants.filter(h => h.zone === me.zone && h.available), h => `${h.name} (${h.hours})`)}</select></div>
        <div><label for="address">Delivery address</label><input id="address" name="address" value="${me.address}" minlength="10" required></div>
      </div>
      <p class="error" role="alert"></p><button class="btn primary">Place booking</button></form>
      <p class="empty">Commercial: ${Object.entries(rates.commercial).map(([s, p]) => `${s} gal ${money(p)}`).join(', ')}.</p>`);
  },

  async subsidy() {
    const form = ['None', 'Rejected'].includes(me.subsidy) ? `<form data-form="subsidy" novalidate>
      <label for="category">Category</label><select id="category" name="category" required><option>Household</option><option>Hospital</option><option>Mosque</option></select>
      <label for="proof">Proof details</label><input id="proof" name="proof" minlength="10" placeholder="Utility bill or registration number" required>
      <p class="error" role="alert"></p><button class="btn primary">Apply</button></form>` : '';
    return panel('Subsidy status', `<p>${badge(me.subsidy)} ${me.category ?? ''}</p>${form}`);
  },

  async approvals() { return panel('Subsidised bookings to approve', await bookingTable(b => b.zone === me.zone && b.type === 'subsidised' && b.status === 'Pending', true)); },

  async applications() {
    const users = (await api.list('users')).filter(u => u.zone === me.zone && u.subsidy === 'Pending');
    return panel('Subsidy applications', table(['Name', 'CNIC', 'Category', 'Proof', 'Actions'],
      users.map(u => [u.name, u.cnic, u.category, u.proof ?? '-', btn('verify', u.id, 'Verify', 'primary') + btn('deny', u.id, 'Reject', 'danger')])));
  },

  async disputes() { return panel('Disputed deliveries', await bookingTable(b => b.zone === me.zone && b.status === 'Disputed', true)); },
  async zone() { return panel('All zone bookings', await bookingTable(b => b.zone === me.zone, true)); },

  async dispatch() {
    const [bookings, tankers, users] = await Promise.all([api.list('bookings'), api.list('tankers'), api.list('users')]);
    const mine = bookings.filter(b => b.hydrant === me.hydrant);
    const busy = mine.filter(b => ACTIVE.includes(b.status));
    const busyT = busy.map(b => b.tanker), busyD = busy.map(b => b.driver);
    const drivers = users.filter(u => u.role === 'driver' && u.hydrant === me.hydrant && u.active && !busyD.includes(u.id));
    const rows = mine.filter(b => ['Approved', 'Assigned', 'Filled'].includes(b.status)).map(b => {
      const free = tankers.filter(t => t.hydrant === me.hydrant && t.available && t.size === b.size && !busyT.includes(t.id));
      const action = b.status === 'Assigned' ? btn('fill', b.id, 'Tanker filled', 'primary') : b.status === 'Filled' ? btn('dispatch', b.id, 'Tanker left', 'primary')
        : `<form data-form="assign" data-id="${b.id}"><select name="tanker" aria-label="Tanker" required><option value="">Tanker</option>${options(free, t => t.plate)}</select>
           <select name="driver" aria-label="Driver" required><option value="">Driver</option>${options(drivers, d => d.name)}</select><button class="btn primary">Assign</button></form>`;
      return [b.id, b.customerName, b.size.toLocaleString() + ' gal', badge(b.status), action];
    });
    return panel('Bookings to dispatch', table(['ID', 'Customer', 'Size', 'Status', 'Action'], rows) + '<p class="error" role="alert"></p>');
  },

  async fleet() {
    const [tankers, hydrant] = await Promise.all([api.list('tankers'), find('hydrants', me.hydrant)]);
    return panel(hydrant.name, `<p>${badge(hydrant.available ? 'Available' : 'Unavailable')} ${btn('toggleHydrant', hydrant.id, hydrant.available ? 'Mark unavailable' : 'Mark available')}</p>`)
      + panel('Tankers', table(['Plate', 'Size', 'Status', 'Action'], tankers.filter(t => t.hydrant === me.hydrant)
        .map(t => [t.plate, t.size.toLocaleString() + ' gal', badge(t.available ? 'Available' : 'Unavailable'), btn('toggleTanker', t.id, t.available ? 'Mark unavailable' : 'Mark available')])));
  },

  async trips() {
    const trips = (await api.list('bookings')).filter(b => b.driver === me.id && ['Dispatched', 'Arrived'].includes(b.status));
    return trips.length ? `<div class="trips">${trips.map(b => `<article class="panel trip">
      <h2>${b.customerName}</h2><p>${b.address}<br>${b.size.toLocaleString()} gallons ${badge(b.status)}</p>
      <div class="actions">
        ${b.status === 'Dispatched' ? btn('arrive', b.id, 'Arrived', 'primary') : btn('deliver', b.id, 'Delivered', 'primary')}
        <select id="reason-${b.id}" aria-label="Failure reason"><option>House locked</option><option>Road blocked</option><option>Customer unavailable</option></select>
        ${btn('fail', b.id, 'Failed', 'danger')}
      </div></article>`).join('')}</div>` : panel('My trips', '<p class="empty">No trips assigned.</p>');
  },

  async overview() {
    const [bookings, hydrants] = await Promise.all([api.list('bookings'), api.list('hydrants')]);
    const done = bookings.filter(b => ['Delivered', 'Confirmed'].includes(b.status));
    const stat = (n, l) => `<div class="panel stat"><strong>${n}</strong>${l}</div>`;
    return `<div class="stats">${stat(bookings.length, 'Bookings')}${stat(done.length, 'Delivered')}${stat(bookings.filter(b => b.status === 'Disputed').length, 'Disputes')}${stat(money(done.reduce((s, b) => s + b.amount, 0)), 'Revenue')}</div>`
      + panel('Hydrant water use', hydrants.map(h => `<p>${h.name}: ${h.used.toLocaleString()} / ${h.quota.toLocaleString()} gal</p><div class="bar"><span style="width:${Math.min(100, h.used / h.quota * 100)}%"></span></div>`).join(''));
  },

  async zones() {
    const [zones, hydrants] = await Promise.all([api.list('zones'), api.list('hydrants')]);
    return panel('Zones', table(['Code', 'Name', 'Hydrants'], zones.map(z => [z.id, z.name, hydrants.filter(h => h.zone === z.id).map(h => h.name).join(', ') || '-']))
      + `<form data-form="zone" novalidate><div class="form-grid"><div><label for="zid">Code</label><input id="zid" name="id" pattern="Z\\d+" placeholder="Z3" required></div>
      <div><label for="zname">Zone name</label><input id="zname" name="name" minlength="3" required></div></div><p class="error" role="alert"></p><button class="btn primary">Add zone</button></form>`);
  },

  async tankers() {
    const [tankers, hydrants, rates] = await Promise.all([api.list('tankers'), api.list('hydrants'), api.rates()]);
    return panel('Tankers', table(['Plate', 'Size', 'Hydrant', 'Status'], tankers.map(t => [t.plate, t.size.toLocaleString() + ' gal', hydrants.find(h => h.id === t.hydrant)?.name, badge(t.available ? 'Available' : 'Unavailable')]))
      + `<form data-form="tanker" novalidate><div class="form-grid"><div><label for="plate">Plate</label><input id="plate" name="plate" pattern="[A-Z]{3}-\\d{3,4}" placeholder="KHI-1234" required></div>
      <div><label for="tsize">Size</label><select id="tsize" name="size" required>${Object.keys(rates.commercial).map(s => `<option value="${s}">${(+s).toLocaleString()} gallons</option>`).join('')}</select></div>
      <div><label for="thydrant">Hydrant</label><select id="thydrant" name="hydrant" required>${options(hydrants, h => h.name)}</select></div></div>
      <p class="error" role="alert"></p><button class="btn primary">Add tanker</button></form>`);
  },

  async hydrants() {
    const [hydrants, tankers] = await Promise.all([api.list('hydrants'), api.list('tankers')]);
    return panel('Hydrants and daily quota', table(['Hydrant', 'Zone', 'Hours', 'Tankers', 'Quota (gal)'], hydrants.map(h => [h.name, h.zone, h.hours, tankers.filter(t => t.hydrant === h.id).length,
      `<form data-form="quota" data-id="${h.id}"><input name="quota" type="number" min="1000" step="1000" value="${h.quota}" aria-label="Quota for ${h.name}" required><button class="btn">Save</button></form>`])));
  },

  async rates() {
    const rates = await api.rates();
    const fields = type => Object.keys(rates.commercial).map(s => `<div><label for="${type}${s}">${type} ${s.toLocaleString()} gal</label><input id="${type}${s}" name="${type}${s}" type="number" min="100" value="${rates[type][s]}" required></div>`).join('');
    return panel('Rates (Rs)', `<form data-form="rates" novalidate><div class="form-grid">${fields('commercial')}${fields('subsidised')}</div><p class="error" role="alert"></p><button class="btn primary">Save rates</button></form>`);
  },

  async users() {
    const users = await api.list('users');
    return panel('User accounts', table(['Name', 'Role', 'Email', 'Status', 'Action'], users.map(u => [u.name, u.role, u.email, badge(u.active ? 'Active' : 'Disabled'),
      u.id === me.id ? '-' : btn('toggleUser', u.id, u.active ? 'Disable' : 'Enable')])));
  }
};

const byId = id => find('bookings', id);
const toggle = (name, key = 'available') => async id => api.update(name, id, { [key]: !(await find(name, id))[key] });
const to = (status, release) => async id => {
  const b = await byId(id);
  await setStatus(b, status, status === 'Failed' ? { failReason: $(`#reason-${id}`).value } : {});
  if (release) await releaseWater(b);
};
const acts = {
  async trail(id) {
    const b = await byId(id);
    $('#dialog-body').innerHTML = `<h2>Booking ${b.id}</h2><ol>${b.history.map(h => `<li>${badge(h.status)} ${h.at} by ${h.by}</li>`).join('')}</ol>`;
    $('#dialog').showModal();
  },
  cancel: to('Cancelled', true), reject: to('Rejected', true), confirm: to('Confirmed'), dispute: to('Disputed'),
  approve: to('Approved'), fill: to('Filled'), resolve: to('Confirmed'), dispatch: to('Dispatched'), arrive: to('Arrived'),
  deliver: to('Delivered'), fail: to('Failed'),
  verify: id => api.update('users', id, { subsidy: 'Verified' }),
  deny: id => api.update('users', id, { subsidy: 'Rejected' }),
  toggleHydrant: toggle('hydrants'), toggleTanker: toggle('tankers'), toggleUser: toggle('users', 'active')
};

/* Each form handler returns an error message, or nothing on success */
const forms = {
  async book(d) {
    const [hydrant, rates, bookings] = await Promise.all([find('hydrants', d.hydrant), api.rates(), api.list('bookings')]);
    const size = +d.size, month = new Date().getMonth();
    if (!hydrant?.available) return 'This hydrant is unavailable.';
    if (hydrant.used + size > hydrant.quota) return 'Hydrant daily water quota is exhausted. Choose another hydrant or size.';
    const used = bookings.filter(b => b.customer === me.id && b.type === 'subsidised' && b.month === month && !['Cancelled', 'Rejected'].includes(b.status)).length;
    if (d.type === 'subsidised' && used >= LIMIT) return `Monthly subsidised limit of ${LIMIT} bookings reached.`;
    const status = d.type === 'subsidised' ? 'Pending' : 'Approved';
    await api.add('bookings', { id: 'B' + Date.now().toString().slice(-6), customer: me.id, customerName: me.name, type: d.type, size, hydrant: d.hydrant, zone: me.zone,
      address: d.address, status, tanker: null, driver: null, amount: rates[d.type][size], month, history: [stamp(status)] });
    await api.update('hydrants', hydrant.id, { used: hydrant.used + size });
    location.hash = 'bookings';
  },
  async subsidy(d) {
    Object.assign(me, { subsidy: 'Pending', category: d.category, proof: d.proof });
    await api.update('users', me.id, { subsidy: 'Pending', category: d.category, proof: d.proof });
    sessionStorage.setItem('user', JSON.stringify(me));
  },
  async assign(d, id) { await setStatus(await byId(id), 'Assigned', { tanker: d.tanker, driver: d.driver }); },
  async zone(d) {
    if ((await api.list('zones')).some(z => z.id === d.id)) return 'Zone code already exists.';
    await api.add('zones', d);
  },
  async tanker(d) {
    const plate = d.plate.toUpperCase();
    if ((await api.list('tankers')).some(t => t.plate === plate)) return 'This plate is already registered.';
    await api.add('tankers', { id: 'T' + Date.now(), hydrant: d.hydrant, size: +d.size, plate, available: true });
  },
  async quota(d, id) { await api.update('hydrants', id, { quota: +d.quota }); },
  async rates(d) {
    const pick = type => Object.fromEntries(Object.keys(d).filter(k => k.startsWith(type)).map(k => [k.slice(type.length), +d[k]]));
    await api.setRates({ commercial: pick('commercial'), subsidised: pick('subsidised') });
  }
};

async function render() {
  const keys = NAV[me.role];
  const key = keys.includes(location.hash.slice(1)) ? location.hash.slice(1) : keys[0];
  $('#nav').innerHTML = keys.map(k => `<a href="#${k}" ${k === key ? 'aria-current="page"' : ''}>${k}</a>`).join('');
  $('#hero').style.setProperty('--img', `url(img/${me.role}.jpg)`);
  $('#hero').innerHTML = `<h2>${HERO[me.role]}</h2><p>${me.name}</p>`;
  $('#view').innerHTML = await views[key]();
}

document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  await acts[el.dataset.act](el.dataset.id);
  if (el.dataset.act !== 'trail') render();
});
document.addEventListener('submit', async e => {
  const form = e.target.closest('[data-form]');
  if (!form) return;
  e.preventDefault();
  const error = form.querySelector('.error') ?? $('#view .error');
  if (!form.checkValidity()) { error.textContent = 'Fill every field correctly.'; return form.reportValidity(); }
  const message = await forms[form.dataset.form](Object.fromEntries(new FormData(form)), form.dataset.id);
  if (message) return error.textContent = message;
  render();
});
$('#logout').addEventListener('click', () => { sessionStorage.clear(); location.replace('login.html'); });
window.addEventListener('hashchange', render);
render();
