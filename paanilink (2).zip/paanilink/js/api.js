const KEY = 'paanilink-db';
let db;

const load = async () => db ??= JSON.parse(localStorage.getItem(KEY)) ?? await (await fetch('data/db.json')).json();
const save = () => localStorage.setItem(KEY, JSON.stringify(db));

export const api = {
  async list(name) { return (await load())[name]; },
  async add(name, item) { (await load())[name].push(item); save(); return item; },
  async update(name, id, patch) {
    const item = (await load())[name].find(i => i.id === id);
    Object.assign(item, patch); save(); return item;
  },
  async setRates(rates) { (await load()).rates = rates; save(); },
  async rates() { return (await load()).rates; }
};
